#!/bin/bash

design_name="video_verification_bfm"
rdir="./release"
tarfile="./release.tar"
ver_file="./version.txt"
ver_file_tmp="./version_tmp.txt"
version_str=`cat $ver_file | grep VERSION | awk -F= '{printf "%s", $2}'`

rtar="./"${design_name}"_"${version_str}".tar.gz"
rzip="./"${design_name}"_"${version_str}".zip"

# Grab hash of HEAD of local 
commit_id=`git rev-parse HEAD`

# Check Git Tag matches version number
git_tag=`git name-rev --tags --name-only ${commit_id}`

if [ "${git_tag}" != "${version_str}" ]; then
  echo "ERROR: Version Mismatch: Git Tag ("${git_tag}") and #VERSION from version.txt ("${version_str}") do not match."
  exit
fi
 
# Add Version and Commit ID to Version File
echo "#VERSION="${version_str} > ${ver_file_tmp}
echo "#COMMIT_ID="${commit_id} >> ${ver_file_tmp}

echo "Removing old version.txt and replacing with new version info"
mv ${ver_file_tmp} ${ver_file}

# Delete Existing release directory if it exists
if [ -d "$rdir" ]; then
  echo "Cleaning up old release directory: $rdir"
  rm -r $rdir
fi

# Create a tarball of everything (except this script)
tar cvf $tarfile --exclude mk_release.bash* *

# Create new release directory
echo "Creating Release Directory: $rdir"
mkdir $rdir

# cd into release directory
cd $rdir

# Unpack tarball here
tar xvf ../$tarfile

# Remove non-release files.

# Create Zip and Tarball Archives
tar cvfz ../$rtar *
7z a -tzip ../$rzip

# Clean Up
cd ..
rm -r $rdir
rm -r $tarfile

echo "Release files created:"
echo "  $rtar"
echo "  $rzip"
