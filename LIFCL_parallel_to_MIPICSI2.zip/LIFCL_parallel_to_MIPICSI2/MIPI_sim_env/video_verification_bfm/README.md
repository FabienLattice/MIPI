Revision: 3.0
Date: 09-03-20
Description:
- Simplified Clocking to allow any bitrate to be selected by adjusting BITRATE
  parameter in testbench top level
- Added Robust D-PHY Compliance checks. All spec'ed timings are now checked.
- Simplified Rx D-PHY BFM in preparation to support DSI. Rx D-PHY now simply
  outputs all decoded bytes between HS-Sync pulse and LP-11 state. It is the
  job of the CSI-2 layer to parse the bytes and extract the relevant Pixel
  Data
- Added CRC checking to Rx BFM.
- Added support for new data types in Pixel to Byte and Byte to Pixel blcosk (RAW8, RAW12 and RGB888 in addition to RAW10). 
- Added support for all data types to various functions and Pixel
  Generation/Checking layers. Adding a new data type now requires only the
  relevant pixel to byte and byte to pixel modules to be written. The
  recommended route here is to copy one of the existing ones. It is now a
  trivial matter to add support for new data types.
